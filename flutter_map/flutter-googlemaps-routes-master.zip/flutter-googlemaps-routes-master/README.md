# Google Maps - Polylines and Routes

Code for the video showing how to draw routes on google maps inside your flutter apps using polylines.

How do I code this ? - https://youtu.be/rvXRc1zwFpQ

## Screenshots

![Screenshot_20191128-223427](https://user-images.githubusercontent.com/8137504/69824689-a25ead80-1232-11ea-841e-e41bec6bdb94.png)
